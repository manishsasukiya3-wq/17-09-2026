package com.example.data.remote

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.InputStream
import java.net.URLDecoder
import java.util.UUID
import java.util.concurrent.TimeUnit

class SupabaseStorageManager(
    private val clientProvider: SupabaseClientProvider,
    private val context: Context? = null
) {
    companion object {
        const val BUCKET_QUESTION_IMAGES = "question-images"
    }

    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(30, TimeUnit.SECONDS)
        .build()

    /**
     * Reads image from [uri], resizes/compresses it, and uploads to 'question-images' bucket in Supabase.
     * Returns the permanent public URL on success.
     */
    suspend fun uploadQuestionImage(uri: Uri, overrideContext: Context? = null): Result<String> = withContext(Dispatchers.IO) {
        try {
            val ctx = overrideContext ?: context
                ?: return@withContext Result.failure(Exception("Context is required to process image."))
            val bytes = compressUriToJpeg(uri, ctx)
                ?: return@withContext Result.failure(Exception("Unable to decode or read selected image."))

            val rawBaseUrl = clientProvider.getEffectiveUrl().trim().trimEnd('/')
            val baseUrl = if (rawBaseUrl.startsWith("http://") || rawBaseUrl.startsWith("https://")) {
                rawBaseUrl
            } else {
                "https://$rawBaseUrl"
            }
            val key = clientProvider.getEffectiveAnonKey().trim()

            if (baseUrl.isBlank() || key.isBlank()) {
                return@withContext Result.failure(Exception("Supabase is not configured."))
            }

            val uniqueFileName = "q_${System.currentTimeMillis()}_${UUID.randomUUID().toString().take(8)}.jpg"
            val uploadUrl = "$baseUrl/storage/v1/object/$BUCKET_QUESTION_IMAGES/$uniqueFileName"

            val requestBody = bytes.toRequestBody("image/jpeg".toMediaTypeOrNull())
            val request = Request.Builder()
                .url(uploadUrl)
                .header("apikey", key)
                .header("Authorization", "Bearer $key")
                .header("Content-Type", "image/jpeg")
                .header("x-upsert", "true")
                .post(requestBody)
                .build()

            val response = okHttpClient.newCall(request).execute()
            val responseBodyString = response.body?.string().orEmpty()

            if (response.isSuccessful) {
                val publicUrl = "$baseUrl/storage/v1/object/public/$BUCKET_QUESTION_IMAGES/$uniqueFileName"
                Result.success(publicUrl)
            } else {
                val errorMsg = try {
                    val json = JSONObject(responseBodyString)
                    json.optString("message", json.optString("error", "HTTP ${response.code}"))
                } catch (_: Exception) {
                    "HTTP ${response.code}: $responseBodyString"
                }
                Result.failure(Exception("Storage upload failed ($errorMsg)"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    /**
     * Extracts the object file path inside the 'question-images' bucket from a given image URL or path.
     * Returns null if the URL/path is empty or does not point to an object in the 'question-images' bucket.
     */
    fun extractStoragePath(imageUrlOrPath: String?): String? {
        if (imageUrlOrPath.isNullOrBlank()) return null
        val clean = imageUrlOrPath.substringBefore('?').substringBefore('#').trim()
        val bucket = BUCKET_QUESTION_IMAGES
        val target = "/$bucket/"

        val rawPath = when {
            clean.contains(target, ignoreCase = true) -> {
                val idx = clean.indexOf(target, ignoreCase = true)
                clean.substring(idx + target.length).trimStart('/')
            }
            clean.startsWith("$bucket/", ignoreCase = true) -> {
                clean.substring(bucket.length + 1).trimStart('/')
            }
            !clean.contains("/") && clean.isNotBlank() && clean.contains(".") -> {
                clean
            }
            else -> null
        } ?: return null

        val decodedPath = try {
            URLDecoder.decode(rawPath, "UTF-8").trim()
        } catch (_: Exception) {
            rawPath.trim()
        }

        if (decodedPath.isBlank() ||
            decodedPath.startsWith("/") ||
            decodedPath.contains("..") ||
            decodedPath.equals(bucket, ignoreCase = true)
        ) {
            return null
        }

        return decodedPath
    }

    /**
     * Deletes a question image from Supabase Storage by its public URL, signed URL, or storage path.
     * Safely verifies that only valid objects in the 'question-images' bucket are deleted.
     */
    suspend fun deleteQuestionImage(imageUrlOrPath: String?): Result<Unit> = withContext(Dispatchers.IO) {
        val objectPath = extractStoragePath(imageUrlOrPath)
            ?: return@withContext Result.success(Unit) // No valid question image path found, nothing to delete

        try {
            val rawBaseUrl = clientProvider.getEffectiveUrl().trim().trimEnd('/')
            val baseUrl = if (rawBaseUrl.startsWith("http://") || rawBaseUrl.startsWith("https://")) {
                rawBaseUrl
            } else {
                "https://$rawBaseUrl"
            }
            val key = clientProvider.getEffectiveAnonKey().trim()

            if (baseUrl.isBlank() || key.isBlank()) {
                return@withContext Result.failure(Exception("Supabase is not configured."))
            }

            val deleteUrl = "$baseUrl/storage/v1/object/$BUCKET_QUESTION_IMAGES"
            val payload = JSONObject().apply {
                put("prefixes", JSONArray().apply {
                    put(objectPath)
                })
            }
            val requestBody = payload.toString().toRequestBody("application/json".toMediaTypeOrNull())

            val request = Request.Builder()
                .url(deleteUrl)
                .header("apikey", key)
                .header("Authorization", "Bearer $key")
                .header("Content-Type", "application/json")
                .delete(requestBody)
                .build()

            val response = okHttpClient.newCall(request).execute()
            val responseBodyString = response.body?.string().orEmpty()

            if (response.isSuccessful) {
                Result.success(Unit)
            } else {
                val errorMsg = try {
                    val json = JSONObject(responseBodyString)
                    json.optString("message", json.optString("error", "HTTP ${response.code}"))
                } catch (_: Exception) {
                    "HTTP ${response.code}: $responseBodyString"
                }
                Result.failure(Exception("Storage delete failed ($errorMsg)"))
            }
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    private fun compressUriToJpeg(uri: Uri, ctx: Context): ByteArray? {
        return try {
            val inputStream: InputStream? = ctx.contentResolver.openInputStream(uri)
            val originalBitmap = BitmapFactory.decodeStream(inputStream)
            inputStream?.close()

            if (originalBitmap == null) return null

            // Resize if maximum dimension exceeds 1600px to optimize storage and loading speed
            val maxDimension = 1600
            val width = originalBitmap.width
            val height = originalBitmap.height
            val scaledBitmap = if (width > maxDimension || height > maxDimension) {
                val ratio = width.toFloat() / height.toFloat()
                val (targetWidth, targetHeight) = if (ratio > 1) {
                    Pair(maxDimension, (maxDimension / ratio).toInt())
                } else {
                    Pair((maxDimension * ratio).toInt(), maxDimension)
                }
                Bitmap.createScaledBitmap(originalBitmap, targetWidth, targetHeight, true)
            } else {
                originalBitmap
            }

            val baos = ByteArrayOutputStream()
            scaledBitmap.compress(Bitmap.CompressFormat.JPEG, 85, baos)
            baos.toByteArray()
        } catch (e: Exception) {
            null
        }
    }
}
